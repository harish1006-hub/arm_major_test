/* main_nodeA_TX.c */
#include "header.h"
#include "delay_header.h" 
#include "lcd_4bit_header.h" 	 	
#include "uart0_driver.c"
#include "can2_driver.c" 

#define ldr  16
#define led1  1<<17

main(){	unsigned int adc_value;
float voltage;
float temp;
	CAN2_MSG m1;
	can2_init();
	lcd_init();
	IODIR0 |=led1;
IOSET0=led1;
lcd_cmd(0x80);
lcd_str("welcome");
delay_s(2);

	/*sending data frame*/
	m1.id=0x150;
	m1.rtr=0;//data frame
	m1.dlc=4;
	m1.byteA=0xDDCCBB00;
//	m1.byteB=0;
	
	/*m2.id=0x5;
	m2.dlc=7;
	m2.rtr=1;*/
	while(1)
{
adc_value=adc_read();
voltage = ((adc_value * 3.3) / 1023.0);
temp = voltage * 100.0; 
lcd_cmd(0X80);
lcd_str("Temp:"); 
lcd_float(temp);
//m1.byteA=temp;		
if(((IOPIN0 >> ldr)&1)==1)
{
m1.byteA|=0x000000AA;
	lcd_cmd(0xC0);
lcd_str("LED ON");
IOCLR0= led1;
}
else
{   m1.byteA|=0x000000BB;
lcd_cmd(0xC0);
lcd_str("LED OFF");
IOSET0=led1;}
	can2_tx(m1);//data-frame
		delay_s(1);
}
}
 unsigned int adc_read(void)
{ unsigned int adc;
PINSEL1|= 1<<22;
ADCR=(1<<0)|(4<<8)|(1<<21);
ADCR |= (1<<24);
while(!(ADDR&0X80000000));
adc=((ADDR>>6)&0X3FF);
return adc;
}
